# keebs.pretty

A KiCAD library for hybrid Cherry MX and Alps footprints that supports PCB mounted Cherry stabilizers. This is a revision of files found in [kiibohd/pcb](https://github.com/kiibohd/pcb) and [stormbard/Keyboard.pretty](https://github.com/stormbard/Keyboard.pretty)

Checkout [this tutorial](http://www.accelerated-designs.com/help/KiCad_Library.html)
if you are unfamiliar with importing KiCAD libraries.

If you come across any issues please don't hesitate to report them. Contributions are encouraged!
